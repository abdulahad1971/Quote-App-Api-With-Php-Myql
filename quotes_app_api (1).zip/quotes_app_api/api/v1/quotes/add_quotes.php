<?php

header("Content-Type: application/json");
include __DIR__ . "/../../../includes/config.php";

$category_id   = $_POST['category_id'] ?? null;
$category_name = $_POST['category_name'] ?? null;
$quote_text    = $_POST['quote_text'] ?? null;

if (!$category_id || !$category_name || !$quote_text) {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are required"
    ]);
    exit;
}

$query = "INSERT INTO quotes (category_id, category_name, quote_text) 
          VALUES ('$category_id', '$category_name', '$quote_text')";

if (mysqli_query($conn, $query)) {
    echo json_encode([
        "status" => "success",
        "message" => "Quote added successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => mysqli_error($conn)
    ]);
}

?>
