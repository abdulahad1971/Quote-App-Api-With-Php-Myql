<?php
header('Content-Type: application/json');
include __DIR__ . "/../../../includes/config.php"; // আপনার DB config

$monishi_id = $_POST['monishi_id'] ?? '';

if(empty($monishi_id)){
    echo json_encode(["success"=>false,"error"=>"monishi_id required"]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM monishider WHERE id=?");
$stmt->bind_param("i",$monishi_id);

if($stmt->execute()){
    echo json_encode(["success"=>true]);
}else{
    echo json_encode(["success"=>false,"error"=>$stmt->error]);
}

$stmt->close();
$conn->close();
?>
