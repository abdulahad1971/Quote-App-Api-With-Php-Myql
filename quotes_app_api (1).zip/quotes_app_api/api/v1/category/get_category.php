<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

include __DIR__ . "/../../../includes/config.php";

// Fetch all categories
$result = mysqli_query($conn, "SELECT id, name, image FROM category ORDER BY id DESC");

$categories = array();
while ($row = mysqli_fetch_assoc($result)) {
  $categories[] = $row;
}

// Response
echo json_encode(array(
  'status' => 'success',
  'categories' => $categories
));
exit; // extra safety
?>
