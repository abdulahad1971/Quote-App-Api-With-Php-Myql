<?php
header("Content-Type: application/json");
include __DIR__ . "/../../../includes/config.php"; // DB connection

$query = "SELECT id, image, created_at FROM slider_images ORDER BY id DESC";
$result = mysqli_query($conn, $query);

$images = array();

while($row = mysqli_fetch_assoc($result)){
    $images[] = $row;
}

echo json_encode([
    "status" => "success",
    "images" => $images
]);

mysqli_close($conn);
?>
