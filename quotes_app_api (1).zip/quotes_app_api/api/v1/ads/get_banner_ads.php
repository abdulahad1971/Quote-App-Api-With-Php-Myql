<?php
header('Content-Type: application/json');

include __DIR__ . "/../../../includes/config.php";


// শুধু active banner নেওয়া
$sql = "SELECT ad_unit_id FROM banner_ads WHERE is_active = 1 ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(["status" => "success", "ad_unit_id" => $row['ad_unit_id']]);
} else {
    echo json_encode(["status" => "error", "message" => "No active banner found"]);
}

$conn->close();
?>
