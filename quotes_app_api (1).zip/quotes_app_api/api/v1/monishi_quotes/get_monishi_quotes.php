<?php

header('Content-Type: application/json'); 

include __DIR__ . "/../../../includes/config.php"; 

$result = mysqli_query($conn, "SELECT id, monishi_id, monishi_name, quote, created_at FROM monishider_quotes ORDER BY id DESC");

$quotes = array();

while ($row = mysqli_fetch_assoc($result)) {
    $quotes[] = $row;
}

// JSON response
echo json_encode(
    array(
        'status' => 'success',
        'quotes' => $quotes
    )
);