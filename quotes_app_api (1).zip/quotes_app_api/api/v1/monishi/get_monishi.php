<?php
header('Content-Type: application/json');
include __DIR__ . "/../../../includes/config.php"; // আপনার DB config

// GET request চেক
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(["success"=>false,"error"=>"Only GET requests allowed"]);
    exit;
}

// Fetch all monishider
$monishider = [];
$res = $conn->query("SELECT * FROM monishider ORDER BY created_at DESC");

if($res){
    while($m = $res->fetch_assoc()){
        $monishider[] = [
            "id" => $m['id'],
            "name" => $m['name'],
            "image" => $m['image'],
            "created_at" => $m['created_at']
        ];
    }
    echo json_encode($monishider);
} else {
    echo json_encode(["success"=>false,"error"=>$conn->error]);
}

$conn->close();
?>
