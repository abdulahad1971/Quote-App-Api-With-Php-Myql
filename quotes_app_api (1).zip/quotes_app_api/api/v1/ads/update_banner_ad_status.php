<?php
header('Content-Type: application/json');

include __DIR__ . "/../../../includes/config.php";

$id = $_POST['id'] ?? 0;
$is_active = $_POST['is_active'] ?? 0;

$stmt = $conn->prepare("UPDATE banner_ads SET is_active = ? WHERE id = ?");
$stmt->bind_param("ii", $is_active, $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Update failed"]);
}

$stmt->close();
$conn->close();
?>
