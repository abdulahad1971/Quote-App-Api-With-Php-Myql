<?php
include __DIR__ . "/../../../includes/config.php";

header("Content-Type: application/json");

if (!isset($_GET['category_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "category_id is required"
    ]);
    exit;
}

$category_id = $_GET['category_id'];

$sql = "SELECT * FROM quotes WHERE category_id = '$category_id' ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

$quotes = [];

while ($row = mysqli_fetch_assoc($result)) {
    $quotes[] = $row;
}

echo json_encode([
    "status" => "success",
    "total" => count($quotes),
    "quotes" => $quotes
]);
