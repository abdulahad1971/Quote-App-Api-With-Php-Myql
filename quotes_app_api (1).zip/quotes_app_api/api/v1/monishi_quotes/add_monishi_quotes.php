<?php

header("Content-Type: application/json");
include __DIR__ . "/../../../includes/config.php";

$monishi_id   = $_POST['monishi_id'] ?? null;
$monishi_name = $_POST['monishi_name'] ?? null;
$quote    = $_POST['quote'] ?? null;

if (!$monishi_id || !$monishi_name || !$quote) {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are required"
    ]);
    exit;
}

$query = "INSERT INTO monishider_quotes (monishi_id, monishi_name, quote) 
          VALUES ('$monishi_id', '$monishi_name', '$quote')";

if (mysqli_query($conn, $query)) {
    echo json_encode([
        "status" => "success",
        "message" => "Quote added successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => mysqli_error($conn)
    ]);
}

?>
