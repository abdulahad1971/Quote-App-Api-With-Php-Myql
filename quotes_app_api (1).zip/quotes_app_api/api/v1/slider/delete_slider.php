<?php
header("Content-Type: application/json");
include __DIR__ . "/../../../includes/config.php";

// POST body থেকে data পড়া
$id = $_POST['id'] ?? null;

if(!$id){
    echo json_encode(["status"=>"error", "message"=>"Slider ID is required"]);
    exit;
}

// delete query
$query = "DELETE FROM slider_images WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);

if(mysqli_stmt_execute($stmt)){
    echo json_encode(["status"=>"success", "message"=>"Slider deleted successfully"]);
}else{
    echo json_encode(["status"=>"error", "message"=>mysqli_error($conn)]);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
