<?php
$host = "localhost";
$user = "programm_quotes_app_bd";
$pass = "*SEVz,GJwe+0";
$db   = "programm_quotes_app";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
} 

?>






