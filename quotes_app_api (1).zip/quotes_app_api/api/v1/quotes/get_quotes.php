<?php

header('Content-Type: application/json'); 

include __DIR__ . "/../../../includes/config.php"; 

$result = mysqli_query($conn, "SELECT id, category_id, category_name, quote_text, created_at FROM quotes ORDER BY id DESC");

$quotes = array();

while ($row = mysqli_fetch_assoc($result)) {
    $quotes[] = $row;
}

// JSON response
echo json_encode(
    array(
        'status' => 'success',
        'quotes' => $quotes
    )
);
